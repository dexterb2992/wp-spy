<?php 
define('WPSPY_HOST', dirname( __FILE__ ).'/wp-spy_/');
die(WPSPY_HOST);