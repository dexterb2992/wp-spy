<link rel="stylesheet" type="text/css" href="<?php echo plugins_url( '/css/style.css', __FILE__ );?>">
<link rel="stylesheet" type="text/css" href="<?php echo plugins_url( '/css/jquery.dataTables.min.css', __FILE__ );?>">
<link rel="stylesheet" type="text/css" href="<?php echo plugins_url( '/css/jquery-ui.css', __FILE__ );?>">