<?php

class SocialConfig{
	
	function FBConfig(){
		return array(
			'APPID' => '596073470493831',
			'APPSECRET' => 'e8d02ed0a87a7ca4290c20fe11f9b673'
		);
	}
}