<script type="text/javascript" src="<?php echo plugins_url( '/js/script.js', __FILE__ );?>"></script>
<script type="text/javascript" src="<?php echo plugins_url( '/js/jquery-ui.min.js', __FILE__ );?>"></script>
<script type="text/javascript" src="<?php echo plugins_url( '/js/jquery.dataTables.min.js', __FILE__ );?>"></script>
<script type="text/javascript" src="<?php echo plugins_url( '/js/fusioncharts.js', __FILE__ );?>"></script>
<script type="text/javascript" src="<?php echo plugins_url( 'js/fusioncharts.theme.zune.js', __FILE__ );?>"></script>
<script type="text/javascript" src="<?php echo plugins_url( 'js/fusioncharts.powercharts.js', __FILE__ );?>"></script>
<script type="text/javascript" src="<?php echo plugins_url( 'js/jquery.timeago.js', __FILE__ );?>"></script>