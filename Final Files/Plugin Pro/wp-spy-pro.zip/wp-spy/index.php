<?php

# It is better to have loved and lost than to never have loved at all.