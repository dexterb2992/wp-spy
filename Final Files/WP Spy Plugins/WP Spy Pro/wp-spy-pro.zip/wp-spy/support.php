<div class="wpspy-wrapper">
	<?php 
		$page = 'wpspy-support';
		include plugin_dir_path( __FILE__ )."classes/config.php";
		include plugin_dir_path( __FILE__ )."_nav.php"; 
		include plugin_dir_path( __FILE__ )."classes/dbhelper.php";
		include plugin_dir_path( __FILE__ )."classes/data.php";
	?>
	<style type="text/css">
	.loading{ display: none; }
	</style>
	<div class="wpspy-content" style="height:1183px;">		
		<div class="wpspy-results row" style="height: 1140px !important;">
			<div class="col-12 tutorial support">
				<iframe height="100%" width="100%" style="height: 1172px !important;" class="video" src="http://cjsuccessteam.net/support/index.php?a=add"></iframe>	
			</div>
		</div>
	</div>
</div>